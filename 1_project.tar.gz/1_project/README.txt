Usage:
Login to the system, create a journal using Create Journal link, share with someone else and see the journals created by you in past from home page.

Login Details:

Username: manoharsteam@gmail.com
Password: asdf1234

Username: user@usermail.com
Password: asdf1234

Username: user@usermail2.com
Password: asdf1234

PythonAnyWhere:
https://manohar899.pythonanywhere.com/iLife
Admin Password: asdf
